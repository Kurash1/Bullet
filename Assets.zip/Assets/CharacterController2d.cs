using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using UnityEngine.Networking;
using System.Collections;
using UnityEngine.SceneManagement;
using System.Linq;

public class CharacterController2d : MonoBehaviour
{
    //Variables
    private float MoveSpeed;
    public float killcount = 0;
    private float score = 0;
    private double timer = 0;
    //Objects
    [SerializeField] private Text scor;
    [SerializeField] Camera Camera;
    [SerializeField] Text BulletField;
    [SerializeField] private Rigidbody2D body;
    [SerializeField] private Transform arrow;
    [SerializeField] private SpriteRenderer render;
    //Constants
    [SerializeField] private float BaseMoveSpeed;
    //Resources
    private int FireballAmount = 0;
    //Abilities
    public Ability[] abilities = new Ability[6];
    bool ghost = false;
    public bool comet = false;
    float ghost_timer = 0;
    void Start()
    {
        for(int i = 0; i < 6; i++)
        {
            switch (PlayerPrefs.GetString("ability" + i))
            {
                case "Shotgun":
                    gameObject.AddComponent<Shotgun>().index = i;
                    break;
            }
        }

        MoveSpeed = BaseMoveSpeed;
        Cursor.lockState = CursorLockMode.Confined;
    }
    public bool getUseByName(string name)
    {
        for(int i = 0; i < abilities.Length; i++)
        {
            if (abilities[i].abilityName == name)
                return abilities[i].use;
        }
        return false;
    }
    public void regenRandomAbility()
    {
        //Local Functions
        bool AnyFalse(Ability[] bools)
        {
            for (int i = 0; i < bools.Length; i++)
                if (!bools[i].use)
                    return true;
            return false;
        }
        void regenAbility(int index)
        {
            abilities[index].element.SetActive(true);
            abilities[index].use = true;
        }
        //Actual Code
        if (AnyFalse(abilities))
        {
            int rand = Random.Range(0, abilities.Length);
            while (abilities[rand].use)
            {
                rand = Random.Range(0, abilities.Length);
            }
            regenAbility(rand);
        }
    }
    void Update()
    {
        bool vector2inrange(float min_x, float max_x, float min_y, float max_y, Vector2 value) {
            return (value.x >= min_x) && (value.x <= max_x) && (value.y >= min_y) && (value.y <= max_y); }
        arrow.up = -transform.position; 
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            SceneManager.LoadScene(0);
        }
        HandleMovement();
        HandleActions();
        HandleCamera();
        timer += Time.deltaTime;
        if (timer > (1f / Mathf.Pow(score+1, 0.33f)))
        {
            scor.text = "Killcount: " + killcount;
            timer = 0;
            SpawnMonster<YellowMonster>();
            if (vector2inrange(-5.12f, 5.12f, -5.12f, 5.12f, transform.position))
            {
                arrow.localPosition = new Vector3(0, 0, 2);
                score += 1;
                if(score % 25 == 0)
                {
                    SpawnMonster<AngryMonster>();
                }
                if(score % 10 == 0)
                {
                    FireballAmount++;
                    BulletField.text = FireballAmount.ToString();
                }
                if(score % 50 == 0)
                {
                    switch (Random.Range(0, 2))
                    {
                        case 0:
                            SpawnMonster<BlackMonster>();
                            break;
                        case 1:
                            SpawnMonster<WhiteMonster>();
                            break;
                    }
                }
                if(score % 150 == 0)
                {
                    SpawnMonster<GhostMonster>();
                }
            }
            else
                arrow.localPosition = new Vector3(0, 0, -1);
        }
        Collider2D[] col = Physics2D.OverlapCircleAll(transform.position, transform.localScale.x / 2);
        for(int i = 0; i < col.Length; i++)
            if (!(ghost|comet) && col[i].tag == "Enemy")
                Death();
    }
    public void Death()
    {
        //Local Function
        IEnumerator GetWorlScore()
        {
            string uri = "http://jesser.vlab.fi/PHP/bullet.php";
            using (UnityWebRequest webRequest = UnityWebRequest.Get(uri + "?score=" + killcount + "&name=" + PlayerPrefs.GetString("name")))
            {
                //Debug.Log(uri + "?score=" + score);
                yield return webRequest.SendWebRequest();
                string[] pages = uri.Split('/');
                int page = pages.Length - 1;

                switch (webRequest.result)
                {
                    case UnityWebRequest.Result.ConnectionError:
                    case UnityWebRequest.Result.DataProcessingError:
                        Debug.LogError(pages[page] + ": Error: " + webRequest.error);
                        break;
                    case UnityWebRequest.Result.ProtocolError:
                        Debug.LogError(pages[page] + ": HTTP Error: " + webRequest.error);
                        break;
                    case UnityWebRequest.Result.Success:
                        break;
                }
            }
        }
        //Code
        StartCoroutine(GetWorlScore());
        if (!File.Exists(Application.dataPath + "\\save.k"))
        {
            File.Create(Application.dataPath + "\\save.k").Close();
            File.WriteAllText(Application.dataPath + "\\save.k", "score = 0");
        }
        string[] savefile = File.ReadAllLines(Application.dataPath + "\\save.k");
        for (int i = 0; i < savefile.Length; i++)
        {
            if(Regex.IsMatch(savefile[i],"score = [0-9]+"))
            {
                int oldscore = int.Parse(new Regex("[0-9]+").Match(savefile[i]).Value);
                if(killcount > oldscore)
                {
                    savefile[i] = "score = " + killcount;
                }
            }
        }
        File.WriteAllLines(Application.dataPath + "\\save.k", savefile);
        SceneManager.LoadScene(1);
        gameObject.SetActive(false);
    }
    void HandleCamera()
    {
        Camera.transform.position = new Vector3(Mathf.Lerp(Camera.transform.position.x, transform.position.x, 0.05f), Mathf.Lerp(Camera.transform.position.y,transform.position.y,0.05f), -10);
    }
    void HandleMovement()
    {
        if (Input.GetKey(KeyCode.LeftShift)|comet) 
            MoveSpeed = BaseMoveSpeed * 2;
        else
            MoveSpeed = BaseMoveSpeed;
        body.velocity = Vector2.ClampMagnitude(new Vector2(
            (Input.GetAxis("Horizontal") * MoveSpeed),
            (Input.GetAxis("Vertical")   * MoveSpeed)
        ),MoveSpeed);
    }
    //void Cast(string name, int scaling, int index)
    //{
    //    switch (name)
    //    {
    //        case "Fire Circle":
    //            abilities[index].use = false;
    //            abilities[index].element.SetActive(false);
    //            for (float i = 0f; i <= Mathf.PI * 2; i += 0.1f)
    //            {
    //                SpawnProjectile<FireCircle>(i);
    //            }
    //            break;
    //        case "Rocket Launcher":
    //            abilities[index].use = false;
    //            abilities[index].element.SetActive(false);
    //            SpawnProjectile<Rocket>();
    //            break;
    //        case "Shotgun":
    //            abilities[index].use = false;
    //            abilities[index].element.SetActive(false);
    //            float angle = Mathf.Atan2(
    //                Camera.ScreenToWorldPoint(Input.mousePosition).y - transform.position.y,
    //                Camera.ScreenToWorldPoint(Input.mousePosition).x - transform.position.x
    //            );
    //            for (float i = -0.6f; i <= 0.6f; i += 0.03f)
    //                SpawnProjectile<FireBall>(angle + i);
    //            break;
    //        case "Machine Gun":
    //            abilities[index].use = false;
    //            MachineGun _ = gameObject.GetComponent<MachineGun>();
    //            if(_ == null)
    //                _ = gameObject.AddComponent<MachineGun>();
    //            _.ammo += 29 + scaling;
    //            _.element = abilities[index].element;
    //            _.key = abilities[index].key;
    //            _.text = abilities[index].text;
    //            break;
    //        case "Ghost":
    //            if (!ghost)
    //            {
    //                abilities[index].use = false;
    //                abilities[index].element.SetActive(false);
    //                ghost = true;
    //                ghost_timer = 0;
    //                render.color = new Color(0, 210f / 255, 255f / 255, 0.5f);
    //            }
    //            break;
    //        case "Alluring Scent":
    //            abilities[index].use = false;
    //            abilities[index].element.SetActive(false);
    //            SpawnMonster<AlluringScent>(Camera.ScreenToWorldPoint(Input.mousePosition));
    //            break;
    //        case "Turret":
    //            abilities[index].use = false;
    //            abilities[index].element.SetActive(false);
    //            SpawnMonster<Turret>(Camera.ScreenToWorldPoint(Input.mousePosition));
    //            break;
    //        case "Teleport":
    //            abilities[index].use = false;
    //            abilities[index].element.SetActive(false);
    //            Vector2 target = Camera.ScreenToWorldPoint(Input.mousePosition);
    //            Vector2 position = transform.position;
    //            float alive = 0.5f;
    //            while (position != target)
    //            {
    //                position = Vector2.MoveTowards(position, target, 0.1f);
    //                shootTimedFireball(Random.Range(0, Mathf.PI * 2), position, alive, 100f);
    //            }
    //            transform.position = target;
    //            break;
    //        case "Wall":
    //            abilities[index].use = false;
    //            abilities[index].element.SetActive(false);
    //            SpawnMonster<Wall>(Vector2.Lerp(transform.position, Camera.ScreenToWorldPoint(Input.mousePosition),0.5f));
    //            break;
    //        case "Comet":
    //            if (gameObject.GetComponent<Comet>() == null)
    //            {
    //                abilities[index].use = false;
    //                comet = true;
    //                gameObject.AddComponent<Comet>().index = index;
    //            }
    //            break;
    //        case "Slash":
    //            abilities[index].use = false;
    //            Sword a = gameObject.GetComponent<Sword>();
    //            if (a == null)
    //                a = gameObject.AddComponent<Sword>();
    //            a.slashesleft += 5;
    //            a.abi = abilities[index];
    //            a.abi.text.text = a.slashesleft.ToString();
    //            break;
    //        case "Necromancy":
    //            abilities[index].element.SetActive(false);
    //            abilities[index].use = false;
    //            GameObject[] ghosts = GameObject.FindGameObjectsWithTag("Ghost");
    //            for(int i = 0; i < ghosts.Length; i++)
    //            {
    //                for (float c = 0f; c <= Mathf.PI * 2; c += 0.1f)
    //                {
    //                    SpawnProjectile<FireCircle>(c,ghosts[i].transform.position);
    //                }
    //                Destroy(ghosts[i]);
    //            }
    //            break;
    //    }
    //}
    void HandleActions()
    {
        if(Input.GetKeyDown(KeyCode.Mouse0) && FireballAmount > 0)
        {
            FireballAmount--;
            BulletField.text = FireballAmount.ToString();
            if (ghost)
                SpawnProjectile<GhostFireBall>();
            else
                SpawnProjectile<FireBall>();
        }

        //for(int i = 0; i < abilities.Length; i++)
        //{
        //    if(Input.GetKeyDown(abilities[i].key) && abilities[i].use)
        //    {
        //        Cast(abilities[i].name, abilities[i].scaling, i);
        //    }
        //}
        //if (ghost)
        //{
        //    ghost_timer += Time.deltaTime;
        //    if(ghost_timer > 10f)
        //    {
        //        ghost = false;
        //        render.color = new Color(0,210f/255,255f/255);
        //    }
        //}
        //if (Input.GetKeyDown(KeyCode.V))
        //{
        //    for(int i = 0; i < abilities.Length; i++)
        //    {
        //        regenRandomAbility();
        //    }
        //}
    }
    public T SpawnMonster<T>() where T : Component
    {
        GameObject gn = new GameObject();
        float angle = Random.Range(0f, 360f);
        gn.transform.position = Vector2.MoveTowards(transform.position, new Vector2(transform.position.x + (Mathf.Cos(angle) * 10), transform.position.y + (Mathf.Sin(angle) * 10)), Random.Range(5f, 10f));
        return gn.AddComponent<T>();
    }
    public T SpawnMonster<T>(Vector2 pos) where T : Component
    {
        GameObject gn = new GameObject();
        gn.transform.position = pos;
        return gn.AddComponent<T>();
    }

    public T SpawnProjectile<T>() where T : FireBall
    {
        GameObject gn = new GameObject();
        gn.transform.position = transform.position;
        return gn.AddComponent<T>();
    }
    void shootTimedFireball(float angle, Vector2 start, float alive, float movespeed)
    {
        GameObject gn = new GameObject();
        gn.transform.position = start;
        TimedFireball _ = gn.AddComponent<TimedFireball>();
        _.angle = angle;
        _.alive = alive;
        _.movespeed = movespeed;
    }
    public T SpawnProjectile<T>(float angle) where T : FireBall
    {
        GameObject gn = new GameObject();
        gn.transform.position = transform.position;
        T _ = gn.AddComponent<T>();
        _.angle = angle;
        return _;
    }
    public T SpawnProjectile<T>(float angle, Vector2 pos) where T : FireBall
    {
        GameObject gn = new GameObject();
        gn.transform.position = pos;
        T _ = gn.AddComponent<T>();
        _.angle = angle;
        return _;
    }

    Vector2 toVector2(Vector3 a)
    {
        return new Vector2(a.x, a.y);
    }
}
