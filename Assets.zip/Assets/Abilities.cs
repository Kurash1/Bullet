using UnityEngine;
using UnityEngine.UI;

public class Ability : MonoBehaviour
{
    public int index;
    public bool use = true;
    public string abilityName;

    public KeyCode key;

    public GameObject element;
    public Image image;
    public Text text;

    public virtual void Start()
    {
        abilityName = PlayerPrefs.GetString("ability" + index);
        key = (KeyCode)System.Enum.Parse(typeof(KeyCode), PlayerPrefs.GetString("ability" + index + "_key"));
        element = GameObject.Find("Ability " + index);
        image = element.transform.GetChild(0).GetChild(0).gameObject.GetComponent<Image>();
        image.sprite = Resources.Load<Sprite>("Abilities\\" + abilityName);
        text = element.transform.GetChild(2).gameObject.GetComponent<Text>();
        text.text = key.ToString();
    }
}

public class Shotgun : Ability
{
    public virtual void Update()
    {
        if (use && Input.GetKeyDown(key))
        {
            Debug.Log("shotgun");
            use = false;
            float angle = Mathf.Atan2(
                Camera.main.ScreenToWorldPoint(Input.mousePosition).y - transform.position.y,
                Camera.main.ScreenToWorldPoint(Input.mousePosition).x - transform.position.x
            );
            for (float i = -0.6f; i <= 0.6f; i += 0.03f)
                SpawnProjectile<FireBall>(angle + i);
        }
    }
    public void SpawnProjectile<T>(float angle) where T : FireBall
    {
        GameObject gn = new GameObject();
        gn.transform.position = transform.position;
        gn.AddComponent<T>().angle = angle;
    }
}

public class MachineGun : MonoBehaviour
{
    public int ammo = 0;
    private float timer = 0;
    public GameObject element;
    public KeyCode key;
    public Text text;
    private void Update()
    {
        T SpawnProjectile<T>() where T : FireBall
        {
            GameObject gn = new GameObject();
            gn.transform.position = transform.position;
            return gn.AddComponent<T>();
        }
        timer += Time.deltaTime;
        if (timer > 0.1f)
        {
            timer = 0;
            ammo--;
            text.text = ammo.ToString();
            SpawnProjectile<FireBall>();
            if (ammo == 0)
            {
                element.SetActive(gameObject.GetComponent<CharacterController2d>().getUseByName("Machine Gun"));
                text.text = key.ToString();
                Destroy(this);
            }
        }
    }
}
public class Comet : MonoBehaviour
{
    public int index;
    private float timer = 0;
    private float timer2 = 0;
    private GameObject element;
    private Image token;
    private Image mask;
    private Text text;
    private string origintext;
    void shootTimedFireball(float angle, Vector2 start, float alive, float movespeed)
    {
        GameObject gn = new GameObject();
        gn.transform.position = start;
        TimedFireball _ = gn.AddComponent<TimedFireball>();
        _.angle = angle;
        _.alive = alive;
        _.movespeed = movespeed;
    }
    private void Start()
    {
        element = GameObject.Find("Ability " + index);
        mask = element.transform.GetChild(0).GetComponent<Image>();
        token = element.transform.GetChild(0).GetChild(0).GetComponent<Image>();
        text = element.transform.GetChild(2).GetComponent<Text>();
        origintext = text.text;
    }
    private void Update()
    {
        timer += Time.deltaTime;
        timer2 += Time.deltaTime;
        if(timer2 > 0.01f)
        {
            timer2 = 0;
            for(int i = 0; i < 5; i++)
                shootTimedFireball(Random.Range(0f,Mathf.PI*2), transform.position, 0.1f, 200f);
        }
        token.color = new Color(1, 1, 1, 1f - (timer / 5));
        mask.color = token.color;
        text.text = ((int)(100 - (timer * 20))).ToString();
        if (timer > 5f)
        {
            token.color = Color.white;
            mask.color = token.color;
            text.text = origintext;
            element.SetActive(gameObject.GetComponent<CharacterController2d>().abilities[index].use);
            gameObject.GetComponent<CharacterController2d>().comet = false;
            Destroy(this);
        }
    }
}

public class Sword : MonoBehaviour
{
    public Ability abi;
    private bool dir = true;
    public int slashesleft;
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse1))
        {
            gameObject.AddComponent<Slash>().dir = dir;
            dir = !dir;
            slashesleft--;
            abi.text.text = slashesleft.ToString();
            if (slashesleft == 0) 
            {
                abi.text.text = abi.key.ToString();
                abi.element.SetActive(false);
                Destroy(this);
            }
        }
    }
}

public class Slash : MonoBehaviour
{
    public bool dir;
    public float startangle;
    private float angle;
    void shootTimedFireball(float angle, Vector2 start, float alive, float movespeed)
    {
        GameObject gn = new GameObject();
        gn.transform.position = start;
        TimedFireball _ = gn.AddComponent<TimedFireball>();
        _.angle = angle;
        _.alive = alive;
        _.movespeed = movespeed;
    }
    private void Start()
    {
        Camera cam = Camera.main;
        startangle += Mathf.Atan2(
            cam.ScreenToWorldPoint(Input.mousePosition).y - transform.position.y,
            cam.ScreenToWorldPoint(Input.mousePosition).x - transform.position.x
        ) + (dir ? -2 : 2);
        angle = startangle;
    }
    private void Update()
    {
        shootTimedFireball(angle, transform.position, 0.15f, 1000f);
        angle += dir ? 0.1f : -0.1f;
        if (dir) { 
            if(angle > (startangle + 4))
            {
                Destroy(this);
            }
        }
        else
        {
            if(angle < (startangle - 4))
            {
                Destroy(this);
            }
        }
    }
}